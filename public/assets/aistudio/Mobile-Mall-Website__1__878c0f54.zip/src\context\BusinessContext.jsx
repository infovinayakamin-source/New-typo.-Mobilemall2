import React, { createContext, useContext, useState, useEffect } from 'react';
import { initialBusinessConfig } from '../data/businessConfig';

const BusinessContext = createContext();

export function BusinessProvider({ children }) {
  const [config, setConfig] = useState(() => {
    const saved = localStorage.getItem('mobile_mall_config');
    if (saved) {
      try {
        return { ...initialBusinessConfig, ...JSON.parse(saved) };
      } catch (e) {
        console.error('Error parsing stored config', e);
      }
    }
    return initialBusinessConfig;
  });

  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);
  const [isStockSheetModalOpen, setIsStockSheetModalOpen] = useState(false);
  const [isDealerModalOpen, setIsDealerModalOpen] = useState(false);
  const [selectedProductForModal, setSelectedProductForModal] = useState(null);

  // RFQ Basket state
  const [rfqBasket, setRfqBasket] = useState(() => {
    const saved = localStorage.getItem('mobile_mall_rfq');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error parsing stored RFQ', e);
      }
    }
    return [];
  });
  const [isRfqDrawerOpen, setIsRfqDrawerOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('mobile_mall_config', JSON.stringify(config));
  }, [config]);

  useEffect(() => {
    localStorage.setItem('mobile_mall_rfq', JSON.stringify(rfqBasket));
  }, [rfqBasket]);

  const updateConfig = (newValues) => {
    setConfig((prev) => ({ ...prev, ...newValues }));
  };

  const resetConfig = () => {
    setConfig(initialBusinessConfig);
    localStorage.removeItem('mobile_mall_config');
  };

  // RFQ Basket Actions
  const addToRfq = (product, quantity = null) => {
    const qty = quantity || product.moq || 5;
    setRfqBasket((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + qty } : item
        );
      }
      return [...prev, { ...product, quantity: qty }];
    });
    setIsRfqDrawerOpen(true);
  };

  const updateRfqQuantity = (productId, quantity) => {
    if (quantity <= 0) {
      removeFromRfq(productId);
      return;
    }
    setRfqBasket((prev) =>
      prev.map((item) => (item.id === productId ? { ...item, quantity } : item))
    );
  };

  const removeFromRfq = (productId) => {
    setRfqBasket((prev) => prev.filter((item) => item.id !== productId));
  };

  const clearRfq = () => {
    setRfqBasket([]);
  };

  const generateWhatsAppUrl = (messageText) => {
    const cleanNumber = config.whatsappNumber.replace(/[^0-9]/g, '');
    const encoded = encodeURIComponent(messageText);
    return `https://wa.me/${cleanNumber}?text=${encoded}`;
  };

  return (
    <BusinessContext.Provider
      value={{
        config,
        updateConfig,
        resetConfig,
        isConfigModalOpen,
        setIsConfigModalOpen,
        isStockSheetModalOpen,
        setIsStockSheetModalOpen,
        isDealerModalOpen,
        setIsDealerModalOpen,
        selectedProductForModal,
        setSelectedProductForModal,
        rfqBasket,
        isRfqDrawerOpen,
        setIsRfqDrawerOpen,
        addToRfq,
        updateRfqQuantity,
        removeFromRfq,
        clearRfq,
        generateWhatsAppUrl,
      }}
    >
      {children}
    </BusinessContext.Provider>
  );
}

export function useBusiness() {
  const context = useContext(BusinessContext);
  if (!context) {
    throw new Error('useBusiness must be used within a BusinessProvider');
  }
  return context;
}
