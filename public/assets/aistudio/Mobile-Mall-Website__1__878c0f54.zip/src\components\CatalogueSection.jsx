import React, { useState, useMemo } from 'react';
import { catalogProducts, categoryList, brandList } from '../data/catalogData';
import { useBusiness } from '../context/BusinessContext';
import {
  Search,
  Filter,
  Grid3X3,
  List,
  Sparkles,
  ShoppingBag,
  MessageCircle,
  Eye,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Package,
  Layers,
  ArrowUpDown,
  Tag,
  Boxes,
  Zap
} from 'lucide-react';

export default function CatalogueSection({
  selectedBrand,
  onSelectBrand,
  searchTerm,
  onSearchChange
}) {
  const { addToRfq, setSelectedProductForModal, generateWhatsAppUrl } = useBusiness();

  const [activeCategory, setActiveCategory] = useState('all');
  const [selectedStorage, setSelectedStorage] = useState('all');
  const [sortBy, setSortBy] = useState('featured');
  const [viewMode, setViewMode] = useState('grid'); // 'grid' | 'table'

  // Filtered and sorted products
  const filteredProducts = useMemo(() => {
    return catalogProducts.filter((product) => {
      if (activeCategory !== 'all' && product.category !== activeCategory) {
        return false;
      }
      if (selectedBrand !== 'all' && product.brand !== selectedBrand) {
        return false;
      }
      if (selectedStorage !== 'all' && !product.storage.includes(selectedStorage)) {
        return false;
      }
      if (searchTerm && searchTerm.trim() !== '') {
        const query = searchTerm.toLowerCase();
        const matchesName = product.name.toLowerCase().includes(query);
        const matchesTag = product.tagline.toLowerCase().includes(query);
        const matchesBrand = product.brand.toLowerCase().includes(query);
        const matchesStorage = product.storage.toLowerCase().includes(query);
        if (!matchesName && !matchesTag && !matchesBrand && !matchesStorage) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.tier1Price - b.tier1Price;
      if (sortBy === 'price-desc') return b.tier1Price - a.tier1Price;
      if (sortBy === 'moq-asc') return a.moq - b.moq;
      if (sortBy === 'stock-desc') return b.stockCount - a.stockCount;
      if (sortBy === 'margin-desc') {
        const marginA = ((a.suggestedMSRP - a.tier1Price) / a.tier1Price) * 100;
        const marginB = ((b.suggestedMSRP - b.tier1Price) / b.tier1Price) * 100;
        return marginB - marginA;
      }
      return 0;
    });
  }, [activeCategory, selectedBrand, selectedStorage, searchTerm, sortBy]);

  const handleWhatsAppProduct = (product, quantity = null) => {
    const qty = quantity || product.moq || 5;
    const rate = qty >= 100 ? product.tier3Price : qty >= 25 ? product.tier2Price : product.tier1Price;
    const total = rate * qty;
    const msg = `*OFFICIAL WHOLESALE ENQUIRY — MOBILE MALL*\n
*Model:* ${product.name}
*Condition:* ${product.condition} (Factory Sealed)
*Storage:* ${product.storage}
*Order Quantity:* ${qty} units (${Math.ceil(qty / product.masterCartonSize)} cartons / lots)
*Wholesale Unit Rate:* $${rate}
*Projected Order Value:* $${total.toLocaleString()}
Please confirm immediate dock allocation and send commercial proforma invoice.`;
    window.open(generateWhatsAppUrl(msg), '_blank');
  };

  const handleOrderMasterBox = (product) => {
    addToRfq(product, product.masterCartonSize);
  };

  const handleOrderSampleLot = (product) => {
    addToRfq(product, product.moq);
  };

  return (
    <section id="catalogue" className="bg-[#F6F3EC] text-[#141414] py-16 sm:py-20 border-b border-[#E2DDD3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with High-Contrast Luxury Feel */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#E5C07B]/30 text-[#8C6D1F] text-xs font-black uppercase tracking-wider mb-2 border border-[#D4AF37]/40">
              <Boxes className="w-3.5 h-3.5 text-[#B89025]" />
              <span>Wholesale Digital Catalogue</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#080808] tracking-tight font-heading">
              WHOLESALE PRODUCTS FOR YOUR BUSINESS
            </h2>
            <p className="text-sm sm:text-base text-[#555555] mt-2 max-w-2xl font-normal">
              Browse our product catalogue and request quotations based on your business purchasing requirements.
            </p>
          </div>

          {/* View Mode & Quick Stats */}
          <div className="flex items-center gap-3">
            <span className="text-xs font-bold text-[#444444] bg-white px-3.5 py-2 rounded-xl border border-[#D8D2C6] shadow-sm">
              <strong className="text-[#080808]">{filteredProducts.length}</strong> Wholesale Lots Ready to Dispatch
            </span>

            <div className="flex items-center bg-[#EAE4D8] p-1 rounded-xl border border-[#D5CDC0]">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-lg text-xs font-bold transition-all ${
                  viewMode === 'grid'
                    ? 'bg-white text-[#080808] shadow-sm'
                    : 'text-[#666666] hover:text-[#080808]'
                }`}
                title="Grid Card View"
              >
                <Grid3X3 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`p-2 rounded-lg text-xs font-bold transition-all ${
                  viewMode === 'table'
                    ? 'bg-white text-[#080808] shadow-sm'
                    : 'text-[#666666] hover:text-[#080808]'
                }`}
                title="B2B Wholesale Procurement Spreadsheet"
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Category Pills Switcher */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-3 mb-6">
          {categoryList.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                activeCategory === cat.id
                  ? 'bg-[#05130E] text-white shadow-md'
                  : 'bg-white text-[#555555] hover:text-[#080808] border border-[#DDD7CC] hover:border-[#D4AF37]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Filter Toolbar (Search, Brand, Storage, Sort) */}
        <div className="bg-white rounded-2xl p-4 border border-[#E0D9CD] shadow-sm mb-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Search input */}
            <div className="relative">
              <input
                type="text"
                value={searchTerm || ''}
                onChange={(e) => onSearchChange && onSearchChange(e.target.value)}
                placeholder="Search wholesale models & SKUs..."
                className="w-full bg-[#F6F3EC] text-xs sm:text-sm text-[#080808] placeholder-[#777777] pl-9 pr-3 py-2.5 rounded-xl border border-[#D5CDC0] focus:outline-none focus:border-[#D4AF37]"
              />
              <Search className="w-4 h-4 text-[#777777] absolute left-3 top-1/2 -translate-y-1/2" />
            </div>

            {/* Brand Dropdown */}
            <div className="relative">
              <select
                value={selectedBrand}
                onChange={(e) => onSelectBrand(e.target.value)}
                className="w-full bg-[#F6F3EC] text-xs sm:text-sm text-[#080808] font-medium px-3 py-2.5 rounded-xl border border-[#D5CDC0] focus:outline-none focus:border-[#D4AF37] appearance-none"
              >
                {brandList.map((b) => (
                  <option key={b.id} value={b.id}>
                    Brand: {b.name}
                  </option>
                ))}
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-[#777777]">
                ▼
              </div>
            </div>

            {/* Storage Dropdown */}
            <div className="relative">
              <select
                value={selectedStorage}
                onChange={(e) => setSelectedStorage(e.target.value)}
                className="w-full bg-[#F6F3EC] text-xs sm:text-sm text-[#080808] font-medium px-3 py-2.5 rounded-xl border border-[#D5CDC0] focus:outline-none focus:border-[#D4AF37] appearance-none"
              >
                <option value="all">Storage: All Capacities</option>
                <option value="64GB">64GB Storage</option>
                <option value="128GB">128GB Storage</option>
                <option value="256GB">256GB Storage</option>
                <option value="512GB">512GB Storage</option>
                <option value="1TB">1TB Pro Storage</option>
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-[#777777]">
                ▼
              </div>
            </div>

            {/* Sort Dropdown */}
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full bg-[#F6F3EC] text-xs sm:text-sm text-[#080808] font-medium px-3 py-2.5 rounded-xl border border-[#D5CDC0] focus:outline-none focus:border-[#D4AF37] appearance-none"
              >
                <option value="featured">Sort: Featured Bestsellers</option>
                <option value="margin-desc">Sort: Highest Retailer Margin (%)</option>
                <option value="moq-asc">Sort: Lowest MOQ First</option>
                <option value="price-asc">Sort: Wholesale Price (Low to High)</option>
                <option value="price-desc">Sort: Wholesale Price (High to Low)</option>
                <option value="stock-desc">Sort: Highest Stock Volume</option>
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-[#777777]">
                ▼
              </div>
            </div>
          </div>
        </div>

        {/* Empty state */}
        {filteredProducts.length === 0 && (
          <div className="bg-white rounded-2xl p-12 text-center border border-[#E0D9CD] shadow-sm">
            <AlertCircle className="w-12 h-12 text-[#B89025] mx-auto mb-3" />
            <h3 className="text-lg font-bold text-[#080808]">No matching wholesale stock found</h3>
            <p className="text-sm text-[#666666] mt-1 max-w-md mx-auto">
              Try adjusting your search criteria, clearing brand filters, or request a custom lot from our wholesale desk.
            </p>
            <button
              onClick={() => {
                setActiveCategory('all');
                onSelectBrand('all');
                setSelectedStorage('all');
                onSearchChange && onSearchChange('');
              }}
              className="mt-4 px-5 py-2.5 bg-[#05130E] text-white rounded-xl text-xs font-bold hover:bg-[#143527]"
            >
              Reset All Filters
            </button>
          </div>
        )}

        {/* VIEW MODE 1: GRID VIEW */}
        {viewMode === 'grid' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => {
              const retailerProfit = product.suggestedMSRP - product.tier3Price;
              const marginPercent = Math.round((retailerProfit / product.tier3Price) * 100);
              const masterCartonTotal = product.tier3Price * product.masterCartonSize;

              return (
                <div
                  key={product.id}
                  className="bg-white rounded-2xl border border-[#E2DDD3] hover:border-[#D4AF37] shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden group"
                >
                  {/* Image Container with Badges */}
                  <div className="relative h-56 bg-gradient-to-b from-[#FAF8F5] to-[#EEE8DC] flex items-center justify-center p-4 overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="max-h-full max-w-full object-contain filter drop-shadow-md group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />

                    {/* Top Badges */}
                    <div className="absolute top-3 left-3 flex flex-col gap-1 items-start">
                      <span className="px-2.5 py-1 rounded-full text-[11px] font-black bg-[#05130E] text-white">
                        {product.condition}
                      </span>
                      {product.badges && product.badges[0] && (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-[#E5C07B] text-[#05130E]">
                          {product.badges[0]}
                        </span>
                      )}
                    </div>

                    {/* Stock Status Tag */}
                    <div className="absolute bottom-3 right-3 bg-white/95 backdrop-blur-sm px-2.5 py-1 rounded-lg border border-[#DDD5C7] text-[11px] font-bold text-[#141414] flex items-center gap-1.5 shadow-sm">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      <span>{product.stockCount} Units In Stock</span>
                    </div>

                    {/* Quick View Button */}
                    <button
                      onClick={() => setSelectedProductForModal(product)}
                      className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white text-xs font-bold"
                    >
                      <span className="bg-[#05130E] px-4 py-2 rounded-xl border border-[#E5C07B]/50 flex items-center gap-1.5 font-bold">
                        <Eye className="w-4 h-4 text-[#E5C07B]" />
                        <span>Quick Spec Sheet</span>
                      </span>
                    </button>
                  </div>

                  {/* Product Details Body */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Brand & Storage */}
                      <div className="flex items-center justify-between text-xs text-[#777777] mb-1">
                        <span className="uppercase tracking-wider font-extrabold text-[#967415]">
                          {product.brand} • WHOLESALE LOT
                        </span>
                        <span className="font-bold bg-[#EFE9DD] px-2 py-0.5 rounded text-[#333333]">
                          {product.storage}
                        </span>
                      </div>

                      {/* Title */}
                      <h3
                        onClick={() => setSelectedProductForModal(product)}
                        className="text-base font-extrabold text-[#080808] group-hover:text-[#967415] transition-colors cursor-pointer font-heading"
                      >
                        {product.name}
                      </h3>

                      <p className="text-xs text-[#555555] line-clamp-1 mt-0.5">
                        {product.tagline}
                      </p>

                      {/* Master Carton Packaging Summary */}
                      <div className="mt-3 py-2 px-3 rounded-lg bg-[#FAF7F2] border border-[#E5DFD3] flex items-center justify-between text-[11px]">
                        <span className="flex items-center gap-1.5 font-bold text-[#444444]">
                          <Package className="w-3.5 h-3.5 text-[#967415]" />
                          <span>Master Box: {product.masterCartonSize} Units</span>
                        </span>
                        <span className="font-extrabold text-[#080808]">
                          ${masterCartonTotal.toLocaleString()} / carton
                        </span>
                      </div>

                      {/* Wholesale Pricing Tiers Matrix */}
                      <div className="mt-3 bg-[#FAF8F3] rounded-xl p-3 border border-[#E5DFD3]">
                        <div className="flex items-center justify-between text-xs font-black text-[#777777] mb-2 pb-1 border-b border-[#E5DFD3]">
                          <span>WHOLESALE VOLUME TIER</span>
                          <span>EX-WAREHOUSE RATE</span>
                        </div>
                        <div className="space-y-1.5 text-xs">
                          <div className="flex items-center justify-between text-[#141414]">
                            <span>Tier 1 (MOQ {product.moq}–24 pcs):</span>
                            <span className="font-extrabold text-sm text-[#080808]">${product.tier1Price}</span>
                          </div>
                          <div className="flex items-center justify-between text-[#444444]">
                            <span>Tier 2 (25–99 pcs):</span>
                            <span className="font-bold text-[#967415]">${product.tier2Price}</span>
                          </div>
                          <div className="flex items-center justify-between text-[#141414] bg-[#EFE9DD] px-2 py-1 rounded">
                            <span className="font-black">Master Lot (100+ pcs):</span>
                            <span className="font-black text-sm text-[#05130E]">${product.tier3Price}</span>
                          </div>
                        </div>

                        {/* Retail Margin Pill */}
                        <div className="mt-2.5 pt-2 border-t border-[#E5DFD3] flex items-center justify-between text-[11px]">
                          <span className="text-[#666666]">MSRP: ${product.suggestedMSRP}</span>
                          <span className="font-black text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                            <TrendingUp className="w-3 h-3" />
                            <span>+{marginPercent}% Dealer Margin</span>
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons: Add To Cart & Buy Now */}
                    <div className="mt-4 pt-3 border-t border-[#EFE9DD]">
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => addToRfq(product, product.moq || 5)}
                          className="w-full py-2.5 px-2 bg-[#05130E] hover:bg-[#143828] text-white rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-[0.98]"
                          title="Add To Cart"
                        >
                          <ShoppingBag className="w-3.5 h-3.5 text-[#E5C07B]" />
                          <span>Add To Cart</span>
                        </button>

                        <button
                          onClick={() => handleWhatsAppProduct(product, product.moq || 5)}
                          className="w-full py-2.5 px-2 bg-[#25D366] hover:bg-[#20ba59] text-black font-black rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-[0.98]"
                          title="Buy Now"
                        >
                          <Zap className="w-3.5 h-3.5 fill-current" />
                          <span>Buy Now</span>
                        </button>
                      </div>
                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* VIEW MODE 2: B2B WHOLESALE SPREADSHEET TABLE */}
        {viewMode === 'table' && (
          <div className="bg-white rounded-2xl border border-[#E0D9CD] shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm text-[#141414]">
                <thead className="bg-[#05130E] text-white uppercase text-[11px] font-black tracking-wider">
                  <tr>
                    <th scope="col" className="px-4 py-3.5">Model / SKU</th>
                    <th scope="col" className="px-4 py-3.5">Brand</th>
                    <th scope="col" className="px-4 py-3.5">Carton Packaging</th>
                    <th scope="col" className="px-4 py-3.5">In Stock</th>
                    <th scope="col" className="px-4 py-3.5">MOQ</th>
                    <th scope="col" className="px-4 py-3.5">Tier 1 Rate</th>
                    <th scope="col" className="px-4 py-3.5">Tier 2 Rate</th>
                    <th scope="col" className="px-4 py-3.5">Master Lot</th>
                    <th scope="col" className="px-4 py-3.5">Retail Margin</th>
                    <th scope="col" className="px-4 py-3.5 text-right">Wholesale Procurement</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EAE4D8]">
                  {filteredProducts.map((p) => {
                    const margin = Math.round(((p.suggestedMSRP - p.tier3Price) / p.tier3Price) * 100);
                    return (
                      <tr key={p.id} className="hover:bg-[#FAF7F2] transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <img
                              src={p.image}
                              alt={p.name}
                              className="w-10 h-10 object-contain rounded bg-[#EFE9DD] p-1 flex-shrink-0"
                            />
                            <div>
                              <div
                                onClick={() => setSelectedProductForModal(p)}
                                className="font-black text-[#080808] hover:text-[#967415] cursor-pointer"
                              >
                                {p.name}
                              </div>
                              <div className="text-[11px] text-[#666666]">{p.storage} • {p.condition}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 uppercase font-extrabold text-[11px] text-[#967415]">
                          {p.brand}
                        </td>
                        <td className="px-4 py-3 font-semibold text-[#444444]">
                          Carton of {p.masterCartonSize} pcs
                        </td>
                        <td className="px-4 py-3 font-bold text-emerald-800">
                          {p.stockCount} Units
                        </td>
                        <td className="px-4 py-3 font-medium text-[#444444]">
                          {p.moq} pcs
                        </td>
                        <td className="px-4 py-3 font-bold text-[#080808]">
                          ${p.tier1Price}
                        </td>
                        <td className="px-4 py-3 font-bold text-[#967415]">
                          ${p.tier2Price}
                        </td>
                        <td className="px-4 py-3 font-black text-[#05130E] bg-[#EFE9DD]/60">
                          ${p.tier3Price}
                        </td>
                        <td className="px-4 py-3 font-black text-emerald-700">
                          +{margin}%
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => addToRfq(p, p.moq || 5)}
                              className="px-3 py-1.5 bg-[#05130E] text-white hover:bg-[#143828] rounded-lg text-xs font-black flex items-center gap-1.5 transition-all shadow-sm active:scale-[0.98]"
                              title="Add To Cart"
                            >
                              <ShoppingBag className="w-3.5 h-3.5 text-[#E5C07B]" />
                              <span>Add To Cart</span>
                            </button>
                            <button
                              onClick={() => handleWhatsAppProduct(p, p.moq || 5)}
                              className="px-3 py-1.5 bg-[#25D366] text-black hover:bg-[#20ba59] rounded-lg text-xs font-black flex items-center gap-1.5 transition-all shadow-sm active:scale-[0.98]"
                              title="Buy Now"
                            >
                              <Zap className="w-3.5 h-3.5 fill-current" />
                              <span>Buy Now</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

      </div>
    </section>
  );
}
