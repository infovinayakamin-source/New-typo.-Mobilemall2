import React, { useState, useEffect } from 'react';
import { useBusiness } from '../context/BusinessContext';
import {
  Phone,
  MessageCircle,
  FileSpreadsheet,
  ShoppingBag,
  SlidersHorizontal,
  Menu,
  X,
  Search,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  Send
} from 'lucide-react';

export default function Navbar({ onSearchChange, searchTerm }) {
  const {
    config,
    setIsConfigModalOpen,
    setIsStockSheetModalOpen,
    setIsDealerModalOpen,
    rfqBasket,
    setIsRfqDrawerOpen,
    generateWhatsAppUrl
  } = useBusiness();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [activeNav, setActiveNav] = useState('Home');

  const totalRfqUnits = rfqBasket.reduce((sum, item) => sum + item.quantity, 0);

  // Exactly 7 clean, focused, premium wholesale menu items including Contact Us
  const menuItems = [
    { name: 'Home', href: '#hero' },
    { name: 'About Us', href: '#about' },
    { name: 'Smartphones', href: '#smartphones' },
    { name: 'Tablets & iPads', href: '#tablets' },
    { name: 'Why Choose Us', href: '#why-choose-us' },
    { name: 'How It Works', href: '#how-it-works' },
    { name: 'Contact Us', href: '#contact', isHighlight: true }
  ];

  const handleWhatsAppGeneralClick = () => {
    const text = `Hello Mobile Mall Wholesale Desk. I am an electronics retailer requesting today's wholesale rate sheet and master carton availability.`;
    window.open(generateWhatsAppUrl(text), '_blank');
  };

  const handleJoinBroadcast = () => {
    const text = `Hello Mobile Mall. Please add my number to your Daily 09:30 AM Wholesale Rate Broadcast list for retailers.`;
    window.open(generateWhatsAppUrl(text), '_blank');
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-[#05130E]/95 backdrop-blur-md border-b border-[#143527] transition-all">
      {/* Main Luxury Header Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-4">
          
          {/* Brand Logo & Wordmark */}
          <a href="#hero" className="flex items-center gap-3.5 flex-shrink-0 group">
            <div className="relative">
              <img
                src={config.logoUrl}
                alt="Mobile Mall Wholesale"
                className="w-12 h-12 rounded-full object-cover border-2 border-[#E5C07B]/80 group-hover:border-[#F3E5AB] shadow-lg shadow-[#E5C07B]/15 transition-all duration-300"
                onError={(e) => {
                  e.target.src = '/mobile-mall-logo.jpg';
                }}
              />
              <div className="absolute -bottom-1 -right-1 bg-[#E5C07B] text-[#05130E] text-[8px] font-black px-1.5 py-0.2 rounded-full uppercase tracking-tighter shadow-sm">
                B2B
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl sm:text-2xl font-extrabold tracking-tight text-white group-hover:text-[#F3E5AB] transition-colors font-heading">
                  MOBILE <span className="gold-gradient-text font-black">MALL</span>
                </span>
              </div>
              <p className="text-[10px] text-[#E5C07B] tracking-wider uppercase font-extrabold">
                Wholesale Mobiles • Tablets • iPads
              </p>
            </div>
          </a>

          {/* Premium Desktop Navigation Bar — Exactly 7 Menus */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {menuItems.map((item) => {
              const isActive = activeNav === item.name;
              return (
                <a
                  key={item.name}
                  href={item.href}
                  onClick={() => setActiveNav(item.name)}
                  className={`relative px-3 py-2 rounded-lg text-xs xl:text-sm font-semibold tracking-wide transition-all duration-200 group ${
                    item.isHighlight
                      ? 'text-[#E5C07B] hover:text-white bg-[#0A2219]/80 border border-[#E5C07B]/40 hover:border-[#E5C07B]'
                      : isActive
                      ? 'text-[#F3E5AB] font-bold'
                      : 'text-[#C4D6CD] hover:text-[#E5C07B]'
                  }`}
                >
                  <span>{item.name}</span>
                  
                  {/* Subtle Underline Hover Glint */}
                  <span
                    className={`absolute bottom-0.5 left-3 right-3 h-[2px] bg-gradient-to-r from-transparent via-[#E5C07B] to-transparent transition-all duration-300 ${
                      isActive ? 'opacity-100 scale-x-100' : 'opacity-0 scale-x-0 group-hover:opacity-100 group-hover:scale-x-100'
                    }`}
                  />
                </a>
              );
            })}
          </nav>

          {/* Right Action Cluster */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Search Toggle Button */}
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2 rounded-xl text-[#A3B8AD] hover:text-[#E5C07B] hover:bg-[#0A2219] transition-all"
              title="Search Wholesale Catalogue"
              aria-label="Toggle search"
            >
              <Search className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>

            {/* Wholesale RFQ Basket Button */}
            <button
              onClick={() => setIsRfqDrawerOpen(true)}
              className="relative flex items-center gap-2 px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-[#0A2219] text-white border border-[#143828] hover:border-[#E5C07B] transition-all"
              title="View Wholesale Quotation Basket"
            >
              <ShoppingBag className="w-4 h-4 text-[#E5C07B]" />
              <span className="hidden xl:inline text-xs">RFQ Basket</span>
              {totalRfqUnits > 0 && (
                <span className="bg-[#E5C07B] text-[#05130E] text-[10px] font-black px-1.5 py-0.2 rounded-full">
                  {totalRfqUnits}
                </span>
              )}
            </button>

            {/* Premium Gold CTA: Get Wholesale Quote */}
            <a
              href="#contact"
              className="hidden sm:inline-flex gold-gradient-btn px-4 py-2 rounded-xl text-xs sm:text-sm font-bold items-center gap-1.5 shadow-md shadow-black/40 hover:brightness-110 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Get Wholesale Quote</span>
            </a>

            {/* Mobile Hamburger Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 lg:hidden text-[#A3B8AD] hover:text-white hover:bg-[#0A2219] rounded-xl transition-all"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>

        {/* Expandable Search Input Bar */}
        {searchOpen && (
          <div className="py-2.5 border-t border-[#143527] flex items-center gap-3 animate-fadeIn">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[#789284] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                autoFocus
                value={searchTerm || ''}
                onChange={(e) => onSearchChange && onSearchChange(e.target.value)}
                placeholder="Search wholesale mobile models, tablets, iPads (e.g., iPhone 16 Pro, S24 Ultra, M4 iPad)..."
                className="w-full bg-[#0A2219] text-sm text-white placeholder-[#789284] pl-10 pr-10 py-2 rounded-xl border border-[#143828] focus:outline-none focus:border-[#E5C07B] transition-all"
              />
              {searchTerm && (
                <button
                  onClick={() => onSearchChange && onSearchChange('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#789284] hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>
            <button
              onClick={() => setSearchOpen(false)}
              className="text-xs text-[#A3B8AD] hover:text-white px-2 py-1"
            >
              Close
            </button>
          </div>
        )}
      </div>

      {/* Mobile Drawer Menu — Clean 7 Menus */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#071A13] border-b border-[#143527] px-4 pt-3 pb-6 space-y-3 animate-fadeIn">
          {/* Mobile Search */}
          <div className="relative w-full mb-3">
            <input
              type="text"
              value={searchTerm || ''}
              onChange={(e) => onSearchChange && onSearchChange(e.target.value)}
              placeholder="Search wholesale catalogue..."
              className="w-full bg-[#05130E] text-sm text-white placeholder-[#789284] pl-10 pr-4 py-2 rounded-xl border border-[#143527] focus:outline-none focus:border-[#E5C07B]"
            />
            <Search className="w-4 h-4 text-[#789284] absolute left-3.5 top-1/2 -translate-y-1/2" />
          </div>

          {/* The 7 Navigation Links */}
          <div className="flex flex-col divide-y divide-[#143527]/50 text-sm font-semibold text-white/90">
            {menuItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                onClick={() => {
                  setActiveNav(item.name);
                  setMobileMenuOpen(false);
                }}
                className={`flex items-center justify-between py-2.5 transition-colors ${
                  item.isHighlight
                    ? 'text-[#E5C07B] font-bold'
                    : 'hover:text-[#E5C07B]'
                }`}
              >
                <span>{item.name}</span>
                <ChevronRight className="w-4 h-4 text-[#789284]" />
              </a>
            ))}
          </div>

          {/* Quick Action CTAs in Mobile Drawer */}
          <div className="pt-3 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                handleWhatsAppGeneralClick();
              }}
              className="w-full py-2.5 bg-[#25D366] text-black font-extrabold rounded-xl flex items-center justify-center gap-2 text-sm shadow-md"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Wholesale WhatsApp Desk</span>
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setIsStockSheetModalOpen(true);
              }}
              className="w-full py-2.5 bg-[#0A2219] border border-[#143828] text-[#E5C07B] font-bold rounded-xl flex items-center justify-center gap-2 text-sm"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Download Wholesale Rate Sheet</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
