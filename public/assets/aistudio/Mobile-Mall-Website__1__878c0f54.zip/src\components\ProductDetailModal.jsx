import React, { useState } from 'react';
import { useBusiness } from '../context/BusinessContext';
import {
  X,
  ShieldCheck,
  Package,
  Layers,
  ShoppingBag,
  MessageCircle,
  Truck,
  CheckCircle2,
  FileText,
  ExternalLink,
  Sparkles,
  Zap
} from 'lucide-react';

export default function ProductDetailModal() {
  const {
    selectedProductForModal,
    setSelectedProductForModal,
    addToRfq,
    generateWhatsAppUrl
  } = useBusiness();

  const [quantity, setQuantity] = useState(
    selectedProductForModal ? selectedProductForModal.moq || 5 : 5
  );

  if (!selectedProductForModal) return null;
  const p = selectedProductForModal;

  const currentPrice =
    quantity >= 100 ? p.tier3Price : quantity >= 25 ? p.tier2Price : p.tier1Price;
  const totalAmount = currentPrice * quantity;
  const retailerMargin = Math.round(((p.suggestedMSRP - currentPrice) / currentPrice) * 100);

  const handleWhatsAppInquiry = () => {
    const msg = `Hello Mobile Mall Wholesale Desk. I am inquiring about:
*Model:* ${p.name}
*Condition:* ${p.condition}
*Storage:* ${p.storage}
*Quantity Requested:* ${quantity} units
*Wholesale Unit Rate:* $${currentPrice}
*Total Estimated Value:* $${totalAmount.toLocaleString()}
Please confirm stock availability and send formal proforma invoice.`;
    window.open(generateWhatsAppUrl(msg), '_blank');
  };

  const handleAddToRfq = () => {
    addToRfq(p, quantity);
    setSelectedProductForModal(null);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#141414] border border-[#2A2A2A] rounded-3xl max-w-3xl w-full text-white overflow-hidden shadow-2xl relative my-8">
        
        {/* Close Button */}
        <button
          onClick={() => setSelectedProductForModal(null)}
          className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-[#080808]/80 text-[#9B9B9B] hover:text-white flex items-center justify-center border border-[#2A2A2A] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 p-6 sm:p-8">
          
          {/* Left Column: Image & Quick Badges */}
          <div className="md:col-span-5 flex flex-col items-center justify-between bg-[#080808] rounded-2xl p-6 border border-[#2A2A2A]">
            <div className="w-full flex items-center justify-between text-xs text-[#9B9B9B] mb-4">
              <span className="uppercase font-bold text-[#D4AF37]">{p.brand}</span>
              <span className="bg-[#141414] px-2 py-0.5 rounded text-[11px] font-semibold text-emerald-400">
                {p.stockCount} In Stock
              </span>
            </div>

            <div className="my-auto py-4 flex items-center justify-center">
              <img
                src={p.image}
                alt={p.name}
                className="max-h-60 max-w-full object-contain filter drop-shadow-xl"
              />
            </div>

            <div className="w-full mt-4 pt-3 border-t border-[#2A2A2A] text-center space-y-1">
              <div className="text-xs text-[#9B9B9B]">Packaging & Master Box:</div>
              <div className="text-xs font-bold text-white">
                Master Carton of {p.masterCartonSize} Units (Factory Sealed)
              </div>
            </div>
          </div>

          {/* Right Column: Specifications & Pricing Calculator */}
          <div className="md:col-span-7 flex flex-col justify-between space-y-5">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#D4AF37] text-black uppercase">
                  {p.condition}
                </span>
                <span className="text-xs text-[#9B9B9B]">SKU: {p.id.toUpperCase()}</span>
              </div>

              <h2 className="text-xl sm:text-2xl font-extrabold text-white">
                {p.name}
              </h2>
              <p className="text-xs text-[#9B9B9B] mt-0.5">{p.tagline}</p>

              {/* Wholesale Pricing Tiers Matrix */}
              <div className="mt-4 bg-[#080808] border border-[#2A2A2A] rounded-xl p-3.5 space-y-2">
                <div className="flex items-center justify-between text-[11px] uppercase font-bold text-[#9B9B9B] pb-1 border-b border-[#2A2A2A]">
                  <span>Order Quantity Bracket</span>
                  <span>Unit Wholesale Rate</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#9B9B9B]">Tier 1 (MOQ {p.moq}–24 units):</span>
                  <strong className="text-white text-sm">${p.tier1Price}</strong>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#9B9B9B]">Tier 2 (25–99 units):</span>
                  <strong className="text-[#D4AF37] text-sm">${p.tier2Price}</strong>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#9B9B9B]">Master Lot (100+ units):</span>
                  <strong className="text-[#F4E1A1] text-sm">${p.tier3Price}</strong>
                </div>
                <div className="pt-2 border-t border-[#2A2A2A] flex items-center justify-between text-[11px]">
                  <span className="text-[#777777]">Suggested MSRP: ${p.suggestedMSRP}</span>
                  <span className="font-bold text-emerald-400">+{retailerMargin}% Estimated Spread</span>
                </div>
              </div>

              {/* Technical Spec List */}
              <div className="mt-4 space-y-2 text-xs">
                <div className="bg-[#1A1A1A] rounded-lg p-2 flex justify-between">
                  <span className="text-[#9B9B9B]">Display:</span>
                  <span className="font-semibold text-white text-right">{p.specs.display}</span>
                </div>
                <div className="bg-[#1A1A1A] rounded-lg p-2 flex justify-between">
                  <span className="text-[#9B9B9B]">Processor:</span>
                  <span className="font-semibold text-white text-right">{p.specs.processor}</span>
                </div>
                <div className="bg-[#1A1A1A] rounded-lg p-2 flex justify-between">
                  <span className="text-[#9B9B9B]">Camera:</span>
                  <span className="font-semibold text-white text-right">{p.specs.camera}</span>
                </div>
                <div className="bg-[#1A1A1A] rounded-lg p-2 flex justify-between">
                  <span className="text-[#9B9B9B]">Warranty:</span>
                  <span className="font-semibold text-[#D4AF37] text-right">{p.warranty}</span>
                </div>
                <div className="bg-[#1A1A1A] rounded-lg p-2 flex justify-between">
                  <span className="text-[#9B9B9B]">IMEI Status:</span>
                  <span className="font-semibold text-emerald-400 text-right">{p.specs.imeiStatus}</span>
                </div>
              </div>

              {/* Quantity Picker & Total */}
              <div className="mt-4 pt-3 border-t border-[#2A2A2A] flex items-center justify-between">
                <div>
                  <span className="block text-xs uppercase font-bold text-[#9B9B9B]">
                    Select Order Units:
                  </span>
                  <div className="flex items-center gap-2 mt-1">
                    <button
                      onClick={() => setQuantity((q) => Math.max(p.moq, q - 5))}
                      className="w-8 h-8 rounded-lg bg-[#080808] border border-[#2A2A2A] text-white font-bold hover:border-[#D4AF37]"
                    >
                      -
                    </button>
                    <span className="w-12 text-center font-extrabold text-sm text-[#D4AF37]">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity((q) => q + 5)}
                      className="w-8 h-8 rounded-lg bg-[#080808] border border-[#2A2A2A] text-white font-bold hover:border-[#D4AF37]"
                    >
                      +
                    </button>
                    <span className="text-xs text-[#777777] ml-1">(MOQ: {p.moq})</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="block text-xs uppercase font-bold text-[#9B9B9B]">
                    Total Order Value:
                  </span>
                  <span className="text-xl font-extrabold text-white">
                    ${totalAmount.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            {/* Modal Action Buttons: Add To Cart & Buy Now */}
            <div className="grid grid-cols-2 gap-3 pt-4 border-t border-[#2A2A2A]">
              <button
                onClick={handleAddToRfq}
                className="py-3 px-4 bg-[#080808] border border-[#D4AF37]/50 hover:border-[#D4AF37] text-white font-bold rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
              >
                <ShoppingBag className="w-4 h-4 text-[#D4AF37]" />
                <span>Add To Cart ({quantity})</span>
              </button>

              <button
                onClick={handleWhatsAppInquiry}
                className="py-3 px-4 bg-[#25D366] text-black font-extrabold rounded-xl text-xs sm:text-sm hover:bg-[#20ba59] flex items-center justify-center gap-2 transition-all shadow-md shadow-[#25D366]/20 active:scale-[0.98]"
              >
                <Zap className="w-4 h-4 fill-current" />
                <span>Buy Now</span>
              </button>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}
