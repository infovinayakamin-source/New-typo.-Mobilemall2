# MOBILE MALL — Premium Wholesale Electronics Platform

> "THE GOLD STANDARD IN MOBILE WHOLESALE"

Direct Tier-1 Wholesale Distributor of Original Smartphones, Tablets & iPads for Retailers, Resellers & Bulk Purchasers.

---

## 💎 Brand Identity & Visual System

- **Primary Colors**: Obsidian Black (`#080808`), Charcoal (`#141414`)
- **Metallic Accents**: Luxury Gold (`#D4AF37`), Metallic Champagne (`#E8C978`), Soft Gold (`#F4E1A1`)
- **High-Contrast Canvas**: Clean Off-White (`#F7F7F5`) for the digital product catalogue
- **Typography**: Manrope (Headings) & Plus Jakarta Sans (Body)
- **Official Facebook Channel**: [Mobile Mall Facebook Profile](https://www.facebook.com/profile.php?id=61595620925731)

---

## 🚀 Key B2B Features

1. **Digital B2B Catalogue (Dual View)**:
   - High-contrast Off-White layout (`#F7F7F5`)
   - Grid Card View & Wholesale Spreadsheet Table View
   - Multi-facet filters: Brand, Storage, Category, Sort by Margin % / MOQ / Stock
2. **Tiered Wholesale Pricing Matrix**:
   - Tier 1: Sample MOQ (5–24 pcs)
   - Tier 2: Bulk Retailer (25–99 pcs)
   - Tier 3: Master Dealer (100+ pcs)
   - Projected Retailer Margin Spreads
3. **Interactive Retail Margin Calculator**:
   - Adjust volume slider (5 to 200+ units)
   - Calculates total procurement investment, MSRP turnover, and gross profit
   - 1-click rate lock to WhatsApp
4. **Wholesale RFQ Basket Drawer**:
   - Accumulate lots, adjust quantities
   - Formatted commercial WhatsApp PO generator
5. **Daily Live Stock Sheet (CSV Export)**:
   - Live modal preview of all active lots
   - Browser CSV export for procurement planning
6. **Configurable Placeholders & Settings**:
   - Easily update WhatsApp, phone, dock address, and GST numbers in real time via the UI.

---

## 🛠️ Development & Deployment

```bash
# Install dependencies
npm install

# Run Vite development server
npm run dev

# Build production bundle
npm run build

# Preview production build locally
npm run preview
```
