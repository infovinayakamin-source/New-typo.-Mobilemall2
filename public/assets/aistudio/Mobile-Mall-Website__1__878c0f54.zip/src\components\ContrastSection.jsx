import React from 'react';
import { useBusiness } from '../context/BusinessContext';
import {
  Star,
  CheckCircle2,
  TrendingUp,
  ShieldCheck,
  Truck,
  FileCheck2,
  ArrowRight,
  Sparkles,
  Award,
  Package,
  Layers
} from 'lucide-react';

export default function ContrastSection() {
  const { setIsDealerModalOpen, setIsStockSheetModalOpen, generateWhatsAppUrl } = useBusiness();

  const handleWhatsAppPartner = () => {
    const msg = `Hello Mobile Mall Wholesale Desk. I am an electronics retailer interested in opening an authorized wholesale account.`;
    window.open(generateWhatsAppUrl(msg), '_blank');
  };

  return (
    <section id="about" className="relative overflow-hidden map-blueprint-bg text-[#141414] py-20 px-4 sm:px-6 lg:px-8 border-b border-[#E2DDD3]">
      
      {/* Giant Watermark Typography: "W H O L E S A L E" */}
      <div className="section-watermark-light">
        WHOLESALE
      </div>

      <div className="max-w-5xl mx-auto relative z-10 space-y-10">
        
        {/* Section Header: About Us */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#E5C07B]/30 border border-[#D4AF37]/40 text-[#8C6D1F] text-xs font-black uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>About Mobile Mall</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#080808] tracking-tight font-heading">
            YOUR PARTNER IN MOBILE <span className="text-[#A37B1B]">WHOLESALE</span>
          </h2>

          <p className="text-sm sm:text-base text-[#444444] leading-relaxed">
            Mobile Mall is a wholesale-focused mobile and tablet business connecting retailers, resellers and business buyers with mobile phone, tablet and iPad sourcing opportunities. Our focus is on helping businesses explore products and submit their bulk purchase requirements.
          </p>
        </div>

        {/* Floating Verified Retailer Review Card */}
        <div className="max-w-2xl mx-auto bg-white rounded-2xl p-6 sm:p-7 shadow-xl border border-[#E5DFD5] relative">
          <div className="flex items-center justify-between mb-3">
            <span className="px-2.5 py-1 rounded-full text-[11px] font-black bg-emerald-50 text-emerald-800 border border-emerald-200">
              ✓ Verified Wholesale Partner
            </span>
            <div className="flex items-center gap-1 text-[#E5C07B]">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-current text-[#D4AF37]" />
              ))}
            </div>
          </div>

          <p className="text-xs sm:text-sm text-[#333333] leading-relaxed italic mb-4 font-normal">
            "We source 60 to 80 master cartons of iPhone and Galaxy devices every month from Mobile Mall. Every carton arrives factory sealed with clean IMEI verification and full GST proforma. They've been our most dependable wholesale distribution partner for 3 years running."
          </p>

          <div className="flex items-center gap-3 pt-3 border-t border-[#F0EBE3]">
            <div className="w-10 h-10 rounded-full bg-[#05130E] text-[#E5C07B] font-bold text-xs flex items-center justify-center">
              VK
            </div>
            <div>
              <span className="text-xs font-extrabold text-[#080808] block">Vikas K.</span>
              <span className="text-[11px] text-[#666666] block">Proprietor, Apex Mobile Store Chain (Delhi NCR)</span>
            </div>
          </div>
        </div>

        {/* 4 Wholesale Metrics Matrix */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
          <div className="bg-white/90 backdrop-blur-sm p-4 rounded-xl border border-[#E5DFD5] shadow-sm">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#080808] block font-heading">
              99.8%
            </span>
            <span className="text-[11px] text-[#555555] font-bold mt-0.5 block">
              Clean IMEI Verification
            </span>
            <span className="text-[10px] text-[#777777]">GSX Whitelisted</span>
          </div>

          <div className="bg-white/90 backdrop-blur-sm p-4 rounded-xl border border-[#E5DFD5] shadow-sm">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#080808] block font-heading">
              24h
            </span>
            <span className="text-[11px] text-[#555555] font-bold mt-0.5 block">
              Proforma & Dispatch SLA
            </span>
            <span className="text-[10px] text-[#777777]">Locked Stock Allocation</span>
          </div>

          <div className="bg-white/90 backdrop-blur-sm p-4 rounded-xl border border-[#E5DFD5] shadow-sm">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#080808] block font-heading">
              100+ Lots
            </span>
            <span className="text-[11px] text-[#555555] font-bold mt-0.5 block">
              Daily Master Cartons
            </span>
            <span className="text-[10px] text-[#777777]">Ex-Warehouse Intake</span>
          </div>

          <div className="bg-white/90 backdrop-blur-sm p-4 rounded-xl border border-[#E5DFD5] shadow-sm">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#080808] block font-heading">
              18–24%
            </span>
            <span className="text-[11px] text-[#555555] font-bold mt-0.5 block">
              Retailer Margin Spreads
            </span>
            <span className="text-[10px] text-[#777777]">Protected Dealer Margins</span>
          </div>
        </div>

        {/* Why Choose Mobile Mall: Built Around Your Wholesale Business Needs */}
        <div id="why-choose-us" className="max-w-2xl mx-auto space-y-4 pt-4 scroll-mt-24">
          <div className="text-center space-y-1 mb-2">
            <h3 className="text-xl sm:text-2xl font-extrabold text-[#080808] tracking-tight font-heading">
              BUILT AROUND YOUR WHOLESALE BUSINESS NEEDS
            </h3>
            <p className="text-xs text-[#666666]">
              A specialized sourcing workflow built for mobile retailers, resellers and corporate buyers.
            </p>
          </div>

          <div className="space-y-2.5">
            <div className="bg-white rounded-xl p-3.5 border border-[#E5DFD5] shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-[#222222]">
              <div>
                <span className="font-extrabold text-[#080808] block text-sm">1. WHOLESALE-FOCUSED BUSINESS</span>
                <span className="text-[#555555]">An enquiry experience designed for retailers, resellers and bulk buyers.</span>
              </div>
              <span className="text-[#967415] font-black text-[11px] self-start sm:self-auto bg-[#FDF9ED] px-2 py-0.5 rounded border border-[#E5C07B]/40">B2B Core</span>
            </div>

            <div className="bg-white rounded-xl p-3.5 border border-[#E5DFD5] shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-[#222222]">
              <div>
                <span className="font-extrabold text-[#080808] block text-sm">2. MOBILE & TABLET SOURCING</span>
                <span className="text-[#555555]">Explore smartphones, tablets and iPads for your business requirements.</span>
              </div>
              <span className="text-[#967415] font-black text-[11px] self-start sm:self-auto bg-[#FDF9ED] px-2 py-0.5 rounded border border-[#E5C07B]/40">Devices</span>
            </div>

            <div className="bg-white rounded-xl p-3.5 border border-[#E5DFD5] shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-[#222222]">
              <div>
                <span className="font-extrabold text-[#080808] block text-sm">3. BULK QUOTATION ENQUIRIES</span>
                <span className="text-[#555555]">Share your preferred products and quantities to request pricing information.</span>
              </div>
              <span className="text-[#967415] font-black text-[11px] self-start sm:self-auto bg-[#FDF9ED] px-2 py-0.5 rounded border border-[#E5C07B]/40">Quotations</span>
            </div>

            <div className="bg-white rounded-xl p-3.5 border border-[#E5DFD5] shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-[#222222]">
              <div>
                <span className="font-extrabold text-[#080808] block text-sm">4. DIRECT BUSINESS COMMUNICATION</span>
                <span className="text-[#555555]">Connect with Mobile Mall to discuss product requirements and availability.</span>
              </div>
              <span className="text-[#967415] font-black text-[11px] self-start sm:self-auto bg-[#FDF9ED] px-2 py-0.5 rounded border border-[#E5C07B]/40">Direct Desk</span>
            </div>
          </div>
        </div>

        {/* Bottom CTA Button */}
        <div className="text-center pt-2">
          <a
            href="#contact"
            className="px-8 py-3.5 rounded-xl bg-[#05130E] text-white hover:bg-[#143828] transition-all text-xs sm:text-sm font-extrabold shadow-md inline-flex items-center gap-2"
          >
            <span>GET WHOLESALE QUOTE</span>
            <ArrowRight className="w-4 h-4 text-[#E5C07B]" />
          </a>
        </div>

      </div>
    </section>
  );
}
