@echo off
title Deploy Mobile Mall to GitHub
echo ===================================================================
echo             MOBILE MALL - DEPLOY CODE TO GITHUB
echo   Repository: https://github.com/infovinayakamin-source/mobilemall2
echo ===================================================================
echo.

cd /d "C:\Users\lenovo\.gemini\antigravity\scratch\mobile-mall"

set "PATH=C:\Users\lenovo\AppData\Local\Microsoft\WinGet\Packages\Git.MinGit_Microsoft.Winget.Source_8wekyb3d8bbwe\cmd;C:\Program Files\GitHub CLI;%PATH%"

echo [1/3] Checking GitHub authentication status...
"C:\Program Files\GitHub CLI\gh.exe" auth status >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo GitHub login is required.
    echo Opening browser authentication...
    echo.
    "C:\Program Files\GitHub CLI\gh.exe" auth login --web -p https
    "C:\Program Files\GitHub CLI\gh.exe" auth setup-git
)

echo.
echo [2/3] Linking Git with GitHub CLI credentials...
"C:\Program Files\GitHub CLI\gh.exe" auth setup-git

echo.
echo [3/3] Deploying all files to branch main...
git push -u origin main

if %errorlevel% equ 0 (
    echo.
    echo ===================================================================
    echo   SUCCESS! All code files have been pushed to GitHub:
    echo   https://github.com/infovinayakamin-source/mobilemall2
    echo ===================================================================
) else (
    echo.
    echo -------------------------------------------------------------------
    echo Push could not complete.
    echo Please make sure your GitHub account has write access to:
    echo infovinayakamin-source/mobilemall2
    echo -------------------------------------------------------------------
)

echo.
pause
