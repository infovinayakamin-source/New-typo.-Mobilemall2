import React, { useState } from 'react';
import { useBusiness } from '../context/BusinessContext';
import { MessageCircle, X } from 'lucide-react';

export default function FloatingWhatsApp() {
  const { generateWhatsAppUrl } = useBusiness();
  const [showTooltip, setShowTooltip] = useState(true);

  const handleClick = () => {
    const text = `Hello Mobile Mall Wholesale Desk. I am an electronics retailer interested in today's wholesale availability and pricing tiers.`;
    window.open(generateWhatsAppUrl(text), '_blank');
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      {/* Friendly Tooltip Bubble */}
      {showTooltip && (
        <div className="mb-2 bg-[#141414] text-white border border-[#D4AF37]/40 rounded-2xl py-2 px-3.5 shadow-2xl flex items-center gap-2 text-xs animate-fade-in">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <div>
            <strong className="text-white block font-bold">Wholesale Desk Online</strong>
            <span className="text-[10px] text-[#D4AF37]">Avg. reply: under 5 mins</span>
          </div>
          <button
            onClick={() => setShowTooltip(false)}
            className="text-[#777777] hover:text-white ml-1 p-0.5"
            aria-label="Dismiss tooltip"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating Button with Gold Halo */}
      <button
        onClick={handleClick}
        className="relative group p-4 rounded-full bg-[#25D366] text-black shadow-2xl hover:scale-105 transition-all duration-300 border-2 border-[#D4AF37]"
        title="Chat with Mobile Mall Wholesale Desk"
        aria-label="Connect on WhatsApp"
      >
        <span className="absolute -inset-1 rounded-full bg-[#D4AF37]/30 blur-sm group-hover:bg-[#D4AF37]/50 transition-all -z-10" />
        <MessageCircle className="w-6 h-6 fill-current text-black" />
      </button>
    </div>
  );
}
