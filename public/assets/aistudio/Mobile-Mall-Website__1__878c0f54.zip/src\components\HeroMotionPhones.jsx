import React from 'react';

// Pure Mobile Phone Showcase Inventory (High-Resolution Original Mobile Phones Only)
const mobilePhones = [
  {
    id: 'iphone-16-pro-max',
    name: 'iPhone 16 Pro Max',
    image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=800&q=85',
  },
  {
    id: 'galaxy-s24-ultra',
    name: 'Samsung Galaxy S24 Ultra',
    image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?auto=format&fit=crop&w=800&q=85',
  },
  {
    id: 'galaxy-z-fold6',
    name: 'Samsung Galaxy Z Fold6',
    image: 'https://images.unsplash.com/photo-1580910051074-3eb694886505?auto=format&fit=crop&w=800&q=85',
  },
  {
    id: 'iphone-16-pro',
    name: 'Apple iPhone 16 Pro',
    image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?auto=format&fit=crop&w=800&q=85',
  },
  {
    id: 'oneplus-12',
    name: 'OnePlus 12 5G',
    image: 'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?auto=format&fit=crop&w=800&q=85',
  },
  {
    id: 'flagship-mobile-1',
    name: 'Flagship Smartphone',
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=85',
  },
  {
    id: 'galaxy-flagship-pro',
    name: 'Galaxy Series Flagship',
    image: 'https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?auto=format&fit=crop&w=800&q=85',
  },
  {
    id: 'ultra-flagship-5g',
    name: 'Ultra 5G Smartphone',
    image: 'https://images.unsplash.com/photo-1585060544812-6b45742d762f?auto=format&fit=crop&w=800&q=85',
  }
];

export default function HeroMotionPhones() {
  // Triple the inventory for a truly seamless, infinite horizontal loop
  const displayPhones = [...mobilePhones, ...mobilePhones, ...mobilePhones];

  return (
    <div className="relative w-full my-6 select-none">
      
      {/* Continuous Right-to-Left Keyframe Animations */}
      <style>{`
        @keyframes streamRightToLeft {
          0% {
            transform: translate3d(0, 0, 0);
          }
          100% {
            transform: translate3d(-33.333333%, 0, 0);
          }
        }

        @keyframes verticalFloatOdd {
          0%, 100% {
            transform: translateY(0px) rotate(-0.5deg);
          }
          50% {
            transform: translateY(-16px) rotate(1deg);
          }
        }

        @keyframes verticalFloatEven {
          0%, 100% {
            transform: translateY(-14px) rotate(0.8deg);
          }
          50% {
            transform: translateY(6px) rotate(-0.7deg);
          }
        }

        @keyframes deviceGlassSheen {
          0% {
            transform: translateX(-180%) skewX(-25deg);
            opacity: 0;
          }
          20% {
            opacity: 0.5;
          }
          45% {
            opacity: 0.5;
          }
          70% {
            transform: translateX(220%) skewX(-25deg);
            opacity: 0;
          }
          100% {
            transform: translateX(220%) skewX(-25deg);
            opacity: 0;
          }
        }

        .motion-track-container {
          display: flex;
          width: max-content;
          animation: streamRightToLeft 28s linear infinite !important;
          will-change: transform;
        }

        .motion-track-container.paused {
          animation-play-state: paused !important;
        }

        .motion-track-container:hover {
          animation-play-state: paused;
        }

        .phone-bob-odd {
          animation: verticalFloatOdd 4.2s ease-in-out infinite;
          will-change: transform;
        }

        .phone-bob-even {
          animation: verticalFloatEven 4.8s ease-in-out infinite 0.6s;
          will-change: transform;
        }

        .device-glass-sheen {
          animation: deviceGlassSheen 4.5s ease-in-out infinite;
        }
      `}</style>

      {/* Atmospheric Stage Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[950px] h-[380px] bg-gradient-to-r from-[#10B981]/15 via-[#E5C07B]/20 to-[#10B981]/15 rounded-full blur-[140px] pointer-events-none -z-10" />

      {/* ============================================================
          CONTINUOUS RIGHT-TO-LEFT HORIZONTAL MOTION STREAM
          ONLY Mobile Phone Images (NO PRICE, NO TEXT, NO OTHER THING)
         ============================================================ */}
      <div className="relative py-4 overflow-hidden">
        
        {/* Soft edge blur vignettes for seamless entrance and exit */}
        <div className="absolute top-0 bottom-0 left-0 w-16 sm:w-36 bg-gradient-to-r from-[#030C08] to-transparent z-20 pointer-events-none" />
        <div className="absolute top-0 bottom-0 right-0 w-16 sm:w-36 bg-gradient-to-l from-[#030C08] to-transparent z-20 pointer-events-none" />

        <div className="motion-track-container flex gap-6 sm:gap-8 py-4 px-6 items-center">
          {displayPhones.map((phone, idx) => {
            const isOdd = idx % 2 === 1;
            return (
              <div
                key={`${phone.id}-${idx}`}
                className={`flex-shrink-0 w-[210px] sm:w-[250px] md:w-[270px] ${isOdd ? 'phone-bob-odd' : 'phone-bob-even'}`}
              >
                <div className="group relative rounded-3xl bg-gradient-to-b from-[#0A2219]/60 via-[#071A13]/80 to-[#030C08] border border-[#143828] p-3 shadow-2xl hover:border-[#E5C07B] hover:shadow-[0_15px_35px_rgba(229,192,123,0.3)] transition-all duration-500 transform hover:-translate-y-2 cursor-pointer">
                  
                  {/* Subtle glass reflection gliding across */}
                  <div className="device-glass-sheen absolute inset-0 w-1/2 h-full bg-gradient-to-r from-transparent via-white/15 to-transparent pointer-events-none rounded-3xl z-20" />

                  {/* Pure Floating Mobile Phone Image */}
                  <div className="relative h-60 sm:h-72 w-full flex items-center justify-center overflow-hidden rounded-2xl bg-[#05130E]/80">
                    <img
                      src={phone.image}
                      alt={phone.name}
                      className="h-full w-full object-cover group-hover:scale-108 transition-transform duration-700 rounded-2xl"
                    />
                  </div>

                  {/* Soft Floating Shadow Beneath Phone Pod */}
                  <div className="w-3/4 mx-auto h-2.5 bg-black/70 rounded-full blur-md mt-2 group-hover:w-full transition-all duration-500" />

                </div>
              </div>
            );
          })}
        </div>

      </div>

    </div>
  );
}
