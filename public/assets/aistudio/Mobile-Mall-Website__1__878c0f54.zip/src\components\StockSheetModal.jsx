import React, { useState } from 'react';
import { catalogProducts, brandList } from '../data/catalogData';
import { useBusiness } from '../context/BusinessContext';
import {
  X,
  FileSpreadsheet,
  Download,
  Printer,
  Search,
  CheckCircle2,
  Calendar,
  Layers
} from 'lucide-react';

export default function StockSheetModal() {
  const { isStockSheetModalOpen, setIsStockSheetModalOpen, config } = useBusiness();
  const [selectedBrand, setSelectedBrand] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  if (!isStockSheetModalOpen) return null;

  const filtered = catalogProducts.filter((p) => {
    if (selectedBrand !== 'all' && p.brand !== selectedBrand) return false;
    if (searchTerm && !p.name.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    return true;
  });

  const currentDate = new Date().toLocaleDateString('en-US', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });

  // Export CSV
  const handleDownloadCsv = () => {
    let csv = 'SKU,Model,Brand,Storage,Condition,Available Units,MOQ,Tier 1 Rate ($),Tier 2 Rate ($),Master Lot ($),Suggested MSRP ($)\n';
    filtered.forEach((p) => {
      csv += `"${p.id}","${p.name}","${p.brand}","${p.storage}","${p.condition}",${p.stockCount},${p.moq},${p.tier1Price},${p.tier2Price},${p.tier3Price},${p.suggestedMSRP}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `MobileMall_Wholesale_StockSheet_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#141414] border border-[#2A2A2A] rounded-3xl max-w-4xl w-full text-white overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Modal Top Bar */}
        <div className="p-5 border-b border-[#2A2A2A] bg-[#080808] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 flex items-center justify-center text-[#D4AF37]">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-white flex items-center gap-2">
                <span>Daily Wholesale Inventory Sheet</span>
                <span className="text-xs font-normal text-[#D4AF37] px-2 py-0.5 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30">
                  Live Dispatch
                </span>
              </h2>
              <p className="text-xs text-[#9B9B9B] flex items-center gap-2 mt-0.5">
                <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Date: {currentDate} • Verified Factory Sealed Lots</span>
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsStockSheetModalOpen(false)}
            className="w-9 h-9 rounded-full bg-[#1A1A1A] text-[#9B9B9B] hover:text-white flex items-center justify-center border border-[#2A2A2A]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filters & Actions Bar */}
        <div className="p-4 bg-[#181818] border-b border-[#2A2A2A] flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 w-full sm:w-auto flex-1">
            <div className="relative flex-1 sm:w-64">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Filter stock sheet..."
                className="w-full bg-[#080808] text-xs text-white placeholder-[#888888] pl-8 pr-3 py-2 rounded-lg border border-[#2A2A2A] focus:outline-none focus:border-[#D4AF37]"
              />
              <Search className="w-3.5 h-3.5 text-[#888888] absolute left-2.5 top-1/2 -translate-y-1/2" />
            </div>

            <select
              value={selectedBrand}
              onChange={(e) => setSelectedBrand(e.target.value)}
              className="bg-[#080808] text-xs text-white px-3 py-2 rounded-lg border border-[#2A2A2A] focus:outline-none focus:border-[#D4AF37]"
            >
              {brandList.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={handleDownloadCsv}
              className="px-3.5 py-2 bg-[#D4AF37] text-black font-bold text-xs rounded-lg hover:bg-[#F4E1A1] transition-all flex items-center gap-1.5 shadow-md"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV (Excel)</span>
            </button>

            <button
              onClick={handlePrint}
              className="px-3.5 py-2 bg-[#080808] border border-[#2A2A2A] text-white font-medium text-xs rounded-lg hover:border-[#D4AF37] transition-all flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Print Sheet</span>
            </button>
          </div>
        </div>

        {/* Inventory Table Container */}
        <div className="flex-1 overflow-y-auto p-4">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#080808] text-[#9B9B9B] uppercase font-bold sticky top-0 border-b border-[#2A2A2A]">
              <tr>
                <th className="py-2.5 px-3">SKU</th>
                <th className="py-2.5 px-3">Model / Specification</th>
                <th className="py-2.5 px-3">Condition</th>
                <th className="py-2.5 px-3">Available Units</th>
                <th className="py-2.5 px-3">MOQ</th>
                <th className="py-2.5 px-3">Tier 1 Price</th>
                <th className="py-2.5 px-3">Tier 2 Price</th>
                <th className="py-2.5 px-3">Master Lot</th>
                <th className="py-2.5 px-3">Est. MSRP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A2A2A]/60">
              {filtered.map((item) => (
                <tr key={item.id} className="hover:bg-[#1A1A1A] transition-colors">
                  <td className="py-2.5 px-3 font-mono text-[#D4AF37] text-[11px]">
                    {item.id.toUpperCase()}
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-bold text-white">{item.name}</div>
                    <div className="text-[10px] text-[#888888]">{item.storage} • {item.colors.join(', ')}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#080808] border border-[#2A2A2A] text-[#9B9B9B]">
                      {item.condition}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-bold text-emerald-400">
                    {item.stockCount} Units
                  </td>
                  <td className="py-2.5 px-3 text-[#9B9B9B]">
                    {item.moq} pcs
                  </td>
                  <td className="py-2.5 px-3 font-extrabold text-white">
                    ${item.tier1Price}
                  </td>
                  <td className="py-2.5 px-3 font-bold text-[#D4AF37]">
                    ${item.tier2Price}
                  </td>
                  <td className="py-2.5 px-3 font-bold text-[#F4E1A1]">
                    ${item.tier3Price}
                  </td>
                  <td className="py-2.5 px-3 text-[#777777]">
                    ${item.suggestedMSRP}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer info */}
        <div className="p-4 bg-[#080808] border-t border-[#2A2A2A] text-[11px] text-[#777777] flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>*Pricing subject to daily market exchange rates. IMEI allocation locked upon proforma payment.</span>
          <span className="text-[#D4AF37] font-semibold">Mobile Mall Wholesale Hub</span>
        </div>

      </div>
    </div>
  );
}
