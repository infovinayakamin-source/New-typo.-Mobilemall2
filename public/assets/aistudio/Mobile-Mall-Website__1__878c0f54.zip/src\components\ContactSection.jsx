import React, { useState } from 'react';
import { useBusiness } from '../context/BusinessContext';
import {
  MessageCircle,
  Phone,
  Mail,
  MapPin,
  Send,
  Sparkles,
  CheckCircle2
} from 'lucide-react';

export default function ContactSection() {
  const { config, generateWhatsAppUrl } = useBusiness();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    const msg = `*NEW WHOLESALE ENQUIRY — MOBILE MALL*\n
*Name:* ${formData.name}
*Email:* ${formData.email}
*Phone / WhatsApp:* ${formData.phone}
*Message:* ${formData.message}`;

    setSubmitted(true);
    setTimeout(() => {
      window.open(generateWhatsAppUrl(msg), '_blank');
      setSubmitted(false);
      setFormData({ name: '', email: '', phone: '', message: '' });
    }, 1000);
  };

  return (
    <section id="contact" className="relative overflow-hidden bg-[#040D09] text-white py-20 px-4 sm:px-6 lg:px-8 border-b border-[#143527]">
      
      {/* Giant Background Watermark (matching reference: "C O N T A C T") */}
      <div className="section-watermark">
        CONTACT
      </div>

      <div className="max-w-3xl mx-auto relative z-10 space-y-10">
        
        {/* Section Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#E5C07B]/15 border border-[#E5C07B]/30 text-[#F3E5AB] text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-[#E5C07B]" />
            <span>LET'S CONNECT FOR WHOLESALE BUSINESS</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-heading">
            LOOKING TO BUY MOBILES IN <span className="gold-gradient-text">BULK?</span>
          </h2>

          <p className="text-xs sm:text-sm text-[#A3B8AD] max-w-lg mx-auto leading-relaxed">
            Whether you are a mobile shop owner, reseller or business buyer, share your requirements with Mobile Mall to request a wholesale quotation. Have a bulk mobile, tablet or iPad purchasing requirement? Contact our wholesale team to discuss your business enquiry.
          </p>
        </div>

        {/* Minimalist Contact Form (matching the reference styling) */}
        <div className="emerald-card rounded-2xl p-6 sm:p-8 border border-[#143828] shadow-2xl">
          {submitted ? (
            <div className="text-center py-10 space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
              <h3 className="text-base font-bold text-white">Opening WhatsApp Wholesale Desk...</h3>
              <p className="text-xs text-[#A3B8AD]">Your inquiry details have been formatted for instant response.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#A3B8AD] mb-1.5">
                  Business / Store Name & Contact Person *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Apex Mobile Retailers — Ramesh Patel"
                  className="w-full bg-[#071A13] border border-[#143828] rounded-xl px-4 py-3 text-xs sm:text-sm text-white placeholder-[#5A7466] focus:outline-none focus:border-[#E5C07B] transition-colors"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#A3B8AD] mb-1.5">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="retailer@store.com"
                    className="w-full bg-[#071A13] border border-[#143828] rounded-xl px-4 py-3 text-xs sm:text-sm text-white placeholder-[#5A7466] focus:outline-none focus:border-[#E5C07B] transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#A3B8AD] mb-1.5">
                    WhatsApp Contact Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+91 / International WhatsApp"
                    className="w-full bg-[#071A13] border border-[#143828] rounded-xl px-4 py-3 text-xs sm:text-sm text-white placeholder-[#5A7466] focus:outline-none focus:border-[#E5C07B] transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#A3B8AD] mb-1.5">
                  Models & Bulk Quantities Required *
                </label>
                <textarea
                  required
                  rows="4"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Tell us the mobile phones, tablets, or iPads and approximate quantities your business needs..."
                  className="w-full bg-[#071A13] border border-[#143828] rounded-xl px-4 py-3 text-xs sm:text-sm text-white placeholder-[#5A7466] focus:outline-none focus:border-[#E5C07B] transition-colors"
                ></textarea>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                <button
                  type="submit"
                  className="w-full sm:w-auto gold-gradient-btn px-7 py-3 rounded-xl text-xs sm:text-sm font-extrabold shadow-md hover:brightness-110 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>GET YOUR WHOLESALE QUOTE</span>
                </button>

                <a
                  href={generateWhatsAppUrl("Hello Mobile Mall. I have a bulk mobile, tablet or iPad purchasing requirement and would like to contact your wholesale team.")}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full sm:w-auto px-6 py-3 rounded-xl text-xs sm:text-sm font-bold bg-[#071A13] text-[#E5C07B] border border-[#143828] hover:border-[#E5C07B] transition-all flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>CONTACT OUR WHOLESALE TEAM</span>
                </a>
              </div>
            </form>
          )}
        </div>

      </div>
    </section>
  );
}
