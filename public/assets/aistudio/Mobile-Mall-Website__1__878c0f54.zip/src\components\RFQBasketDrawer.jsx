import React, { useState } from 'react';
import { useBusiness } from '../context/BusinessContext';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  MessageCircle,
  FileSpreadsheet,
  CheckCircle2,
  Copy,
  Sparkles,
  Truck
} from 'lucide-react';

export default function RFQBasketDrawer() {
  const {
    rfqBasket,
    isRfqDrawerOpen,
    setIsRfqDrawerOpen,
    updateRfqQuantity,
    removeFromRfq,
    clearRfq,
    generateWhatsAppUrl
  } = useBusiness();

  const [shopName, setShopName] = useState('');
  const [contactName, setContactName] = useState('');
  const [city, setCity] = useState('');
  const [copied, setCopied] = useState(false);

  if (!isRfqDrawerOpen) return null;

  // Calculate totals
  const totalUnits = rfqBasket.reduce((sum, item) => sum + item.quantity, 0);

  const calculateItemPrice = (item) => {
    if (item.quantity >= 100) return item.tier3Price;
    if (item.quantity >= 25) return item.tier2Price;
    return item.tier1Price;
  };

  const totalWholesaleValue = rfqBasket.reduce((sum, item) => {
    return sum + calculateItemPrice(item) * item.quantity;
  }, 0);

  const buildRfqText = () => {
    let text = `*OFFICIAL WHOLESALE RFQ — MOBILE MALL*\n\n`;
    if (shopName) text += `*Store / Business:* ${shopName}\n`;
    if (contactName) text += `*Buyer / Proprietor:* ${contactName}\n`;
    if (city) text += `*Destination City:* ${city}\n`;
    text += `*Total Units:* ${totalUnits} Units\n\n`;
    text += `*ORDERED ITEMS:*\n`;

    rfqBasket.forEach((item, idx) => {
      const rate = calculateItemPrice(item);
      const sub = rate * item.quantity;
      text += `${idx + 1}. *${item.name}* (${item.storage})\n`;
      text += `   - Condition: ${item.condition}\n`;
      text += `   - Qty: ${item.quantity} units @ $${rate}/unit = $${sub.toLocaleString()}\n`;
    });

    text += `\n*ESTIMATED WHOLESALE TOTAL:* $${totalWholesaleValue.toLocaleString()}\n`;
    text += `Please issue formal commercial proforma invoice and confirm insured freight dispatch schedule.`;
    return text;
  };

  const handleWhatsAppSubmit = () => {
    if (rfqBasket.length === 0) return;
    const msg = buildRfqText();
    window.open(generateWhatsAppUrl(msg), '_blank');
  };

  const handleCopyText = () => {
    const text = buildRfqText();
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/75 backdrop-blur-sm">
      <div className="absolute inset-0" onClick={() => setIsRfqDrawerOpen(false)} />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#141414] border-l border-[#2A2A2A] text-white flex flex-col shadow-2xl">
          
          {/* Header */}
          <div className="p-5 border-b border-[#2A2A2A] flex items-center justify-between bg-[#080808]">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#D4AF37]" />
              <h2 className="text-base font-extrabold text-white">Wholesale RFQ Basket</h2>
              <span className="bg-[#D4AF37] text-black text-xs font-bold px-2 py-0.5 rounded-full">
                {totalUnits} Units
              </span>
            </div>

            <button
              onClick={() => setIsRfqDrawerOpen(false)}
              className="p-1.5 rounded-lg text-[#9B9B9B] hover:text-white hover:bg-[#1C1C1C]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body Content */}
          <div className="flex-1 overflow-y-auto p-5 space-y-5">
            {rfqBasket.length === 0 ? (
              <div className="text-center py-16 space-y-3">
                <ShoppingBag className="w-12 h-12 text-[#9B9B9B] mx-auto opacity-40" />
                <p className="text-sm font-semibold text-[#9B9B9B]">Your quotation basket is empty</p>
                <p className="text-xs text-[#777777] max-w-xs mx-auto">
                  Add smartphone lots or iPad cartons from the catalogue to compile your wholesale order.
                </p>
                <button
                  onClick={() => setIsRfqDrawerOpen(false)}
                  className="mt-4 px-4 py-2 bg-[#080808] border border-[#2A2A2A] text-xs font-bold text-[#D4AF37] rounded-xl hover:border-[#D4AF37]"
                >
                  Browse Catalogue
                </button>
              </div>
            ) : (
              <>
                {/* Product List */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-[#9B9B9B]">
                    <span>Selected Lots ({rfqBasket.length})</span>
                    <button
                      onClick={clearRfq}
                      className="text-rose-400 hover:text-rose-300 text-[11px] underline"
                    >
                      Clear All
                    </button>
                  </div>

                  {rfqBasket.map((item) => {
                    const unitRate = calculateItemPrice(item);
                    const subtotal = unitRate * item.quantity;

                    return (
                      <div
                        key={item.id}
                        className="bg-[#080808] border border-[#2A2A2A] rounded-xl p-3 flex gap-3 relative group"
                      >
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-14 h-14 object-contain rounded bg-[#141414] p-1 flex-shrink-0"
                        />

                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <h4 className="text-xs font-bold text-white truncate">
                              {item.name}
                            </h4>
                            <button
                              onClick={() => removeFromRfq(item.id)}
                              className="text-[#777777] hover:text-rose-400 p-0.5"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="text-[10px] text-[#9B9B9B] mt-0.5">
                            {item.storage} • {item.condition}
                          </div>

                          <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#2A2A2A]">
                            {/* Quantity Adjuster */}
                            <div className="flex items-center gap-1.5 bg-[#141414] rounded-lg border border-[#2A2A2A] px-1.5 py-0.5">
                              <button
                                onClick={() => updateRfqQuantity(item.id, item.quantity - 5)}
                                className="text-[#9B9B9B] hover:text-white text-xs font-bold px-1"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="text-xs font-bold text-[#D4AF37] px-1">
                                {item.quantity}
                              </span>
                              <button
                                onClick={() => updateRfqQuantity(item.id, item.quantity + 5)}
                                className="text-[#9B9B9B] hover:text-white text-xs font-bold px-1"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>

                            {/* Subtotal */}
                            <div className="text-right">
                              <span className="text-[10px] text-[#777777] block">
                                @ ${unitRate}/unit
                              </span>
                              <span className="text-xs font-extrabold text-white">
                                ${subtotal.toLocaleString()}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Retailer Information Form */}
                <div className="bg-[#080808] border border-[#2A2A2A] rounded-xl p-4 space-y-3">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#D4AF37] uppercase tracking-wide">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Retailer Procurement Details</span>
                  </div>

                  <div>
                    <label className="block text-[11px] text-[#9B9B9B] mb-1">
                      Shop / Business Name:
                    </label>
                    <input
                      type="text"
                      value={shopName}
                      onChange={(e) => setShopName(e.target.value)}
                      placeholder="e.g. Metro Electronics Retail"
                      className="w-full bg-[#141414] border border-[#2A2A2A] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] text-[#9B9B9B] mb-1">
                        Contact Person:
                      </label>
                      <input
                        type="text"
                        value={contactName}
                        onChange={(e) => setContactName(e.target.value)}
                        placeholder="Proprietor Name"
                        className="w-full bg-[#141414] border border-[#2A2A2A] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#D4AF37]"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-[#9B9B9B] mb-1">
                        City & State:
                      </label>
                      <input
                        type="text"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        placeholder="Destination City"
                        className="w-full bg-[#141414] border border-[#2A2A2A] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#D4AF37]"
                      />
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Footer Subtotal & Action */}
          {rfqBasket.length > 0 && (
            <div className="p-5 border-t border-[#2A2A2A] bg-[#080808] space-y-3">
              <div className="flex items-center justify-between text-xs text-[#9B9B9B]">
                <span>Total Units Ordered:</span>
                <span className="font-bold text-white">{totalUnits} Units</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white">Estimated Wholesale Total:</span>
                <span className="text-xl font-extrabold text-[#D4AF37]">
                  ${totalWholesaleValue.toLocaleString()}
                </span>
              </div>

              <div className="grid grid-cols-1 gap-2 pt-2">
                <button
                  onClick={handleWhatsAppSubmit}
                  className="w-full py-3 bg-[#25D366] text-black font-bold rounded-xl text-xs sm:text-sm hover:bg-[#20ba59] transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#25D366]/20"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Submit Wholesale RFQ via WhatsApp</span>
                </button>

                <button
                  onClick={handleCopyText}
                  className="w-full py-2 bg-[#141414] border border-[#2A2A2A] text-xs font-semibold text-[#9B9B9B] hover:text-white rounded-xl flex items-center justify-center gap-1.5"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copied ? 'Copied RFQ Summary!' : 'Copy Formal RFQ Text'}</span>
                </button>
              </div>

              <p className="text-[10px] text-[#777777] text-center">
                *Proforma confirmation lock required. Final invoice includes shipping insurance.
              </p>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
