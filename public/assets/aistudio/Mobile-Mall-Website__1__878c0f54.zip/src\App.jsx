import React, { useState } from 'react';
import { BusinessProvider } from './context/BusinessContext';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import DailyRateBroadcastBanner from './components/DailyRateBroadcastBanner';
import BrandBar from './components/BrandBar';
import ContrastSection from './components/ContrastSection';
import ServicesSection from './components/ServicesSection';
import CatalogueSection from './components/CatalogueSection';
import WholesaleCalculator from './components/WholesaleCalculator';
import ReviewsSection from './components/ReviewsSection';
import OrderingProcess from './components/OrderingProcess';
import NewsSection from './components/NewsSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import FloatingWhatsApp from './components/FloatingWhatsApp';
import ProductDetailModal from './components/ProductDetailModal';
import StockSheetModal from './components/StockSheetModal';
import RetailerRegistrationModal from './components/RetailerRegistrationModal';
import ConfigSettingsModal from './components/ConfigSettingsModal';
import RFQBasketDrawer from './components/RFQBasketDrawer';

function MainLayout() {
  const [selectedBrand, setSelectedBrand] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <div className="min-h-screen bg-[#05130E] text-[#F7F7F5] flex flex-col font-sans selection:bg-[#E5C07B] selection:text-[#05130E]">
      {/* Navigation Header */}
      <Navbar
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
      />

      {/* Main Page Flow - 100% Focused on Wholesale Distribution */}
      <main className="flex-1">
        {/* 1. Hero Section (Wordmark, Skyline Silhouette, 4 Wholesale Pillars, 3 Action CTAs, Featured Lots) */}
        <HeroSection />

        {/* 2. Daily Rate Card WhatsApp Broadcast Banner (09:30 AM Daily Morning Release) */}
        <DailyRateBroadcastBanner />

        {/* 3. Brand OEM Lines Strip */}
        <BrandBar
          selectedBrand={selectedBrand}
          onSelectBrand={setSelectedBrand}
        />

        {/* 4. Contrast Ivory Wholesale Blueprint Section (Retailer Quote, 4 Metrics, 4 Stacked Bars) */}
        <ContrastSection />

        {/* 5. What We Offer (Giant SERVICES Watermark) */}
        <ServicesSection />

        {/* 6. Daily Wholesale Inventory & Master Carton Pricing (Dual View & Multi-tier Pricing) */}
        <CatalogueSection
          selectedBrand={selectedBrand}
          onSelectBrand={setSelectedBrand}
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
        />

        {/* 7. Carton & Lot Margin Estimator (Giant CALCULATOR Watermark) */}
        <WholesaleCalculator />

        {/* 8. Retailer Trust Index (Giant REVIEWS Watermark) */}
        <ReviewsSection />

        {/* 9. Your Wholesale Enquiry in 3 Simple Steps */}
        <OrderingProcess />

        {/* 10. News & Market Intake Insights (Giant NEWS Watermark + Connect With Us Banner) */}
        <NewsSection />

        {/* 10. Direct Wholesale Desk Form (Giant CONTACT Watermark) */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating WhatsApp Quick Connect */}
      <FloatingWhatsApp />

      {/* Modals & Slide-over Drawers */}
      <ProductDetailModal />
      <StockSheetModal />
      <RetailerRegistrationModal />
      <ConfigSettingsModal />
      <RFQBasketDrawer />
    </div>
  );
}

export default function App() {
  return (
    <BusinessProvider>
      <MainLayout />
    </BusinessProvider>
  );
}
